# jizzman2Unofficial
Kodi Addon for jizzman2 - Unofficial


This addon is for the website jizzman2.com
it´s a unofficial version and not supported or endorsed by the website.

for now the addon supports;


 browse with categories
 
 hope you enjoy it!
