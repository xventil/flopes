# tugaflixUnofficial
Kodi Addon for TugaFlix - Unofficial


This addon is for the website tugaflix.com 
it´s a unofficial version and not supported or endorsed by the website.

for now the addon supports;

 search movies and series
 auto subs (Pt Language only!)
 browse with categories
 
 hope you enjoy it!
