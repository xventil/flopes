# sexGalaxyUnofficial
Kodi Addon for SexGalaxy - Unofficial


This addon is for the website sexgalaxy.net
it´s a unofficial version and not supported or endorsed by the website.

for now the addon supports;


 browse with categories
 
 hope you enjoy it!
